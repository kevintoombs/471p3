The source code is included as a visual studio solution.

the exe is also included and can be run with ...

471p3.exe reference.fasta alphabet.txt reads.fasta

Reference files not included, but they can be found at ...
http://www.eecs.wsu.edu/~ananth/CptS571/Programs/Program3/Peach_reference.fasta
http://www.eecs.wsu.edu/~ananth/CptS571/Programs/Program3/Peach_simulated_reads.fasta
http://www.eecs.wsu.edu/~ananth/CptS571/Programs/Program3/Cherry_reads.fasta
http://www.eecs.wsu.edu/~ananth/CptS571/Programs/Program3/DNA_alphabet.txt